package DAL;

public class Repository {


}
