package Services;

import DAL.Repository;
import Entities.Airline;
import Entities.Flight;
import Utils.AirlineOperations;
import Utils.Provider;


import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class TicketManagementService {

    private Provider provider;
    private Repository repository;
    ThreadPoolExecutor threadPoolExecutor;
    Flight flight;


    public TicketManagementService(Repository repository,Integer threads) {
        this.repository = repository;
        this.provider = new Provider(repository);
        this.threadPoolExecutor = (ThreadPoolExecutor)(Executors.newFixedThreadPool(threads));
    }

    public Flight GetCheapestTicketPrice(final String originAirport, final String destinationAirport) throws Exception {
        List<String> airlines = provider.getOnboardedFlights();


        for (final String airline : airlines) {
          final   AirlineOperations airlineOperations = provider.getAirlineOperationsObject(airline);

          Future future = threadPoolExecutor.submit(new Runnable() {
                @Override
                public void run() {
                    Flight flight1 = airlineOperations.getCheapestFlight(originAirport, destinationAirport);

                    if (flight == null || flight1.getPrice() < flight.getPrice()) {
                        flight = flight1;
                    }
                }
            });
        }

        if (flight == null) {
            throw new Exception("Flights not available");
        } else {
            return flight;
        }
    }
}
