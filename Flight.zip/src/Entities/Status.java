package Entities;

public enum Status {
    ONTIME
}
